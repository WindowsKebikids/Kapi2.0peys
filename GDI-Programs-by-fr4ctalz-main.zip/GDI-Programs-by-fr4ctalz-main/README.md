# GDI-Programs
just a buncha stuff i made
